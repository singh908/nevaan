package com.bnpparibas.risk.mrx.mqsim.web;

import com.bnpparibas.risk.mrx.mqsim.consumer.SpeTaskConsumer;
import com.bnpparibas.risk.mrx.mqsim.domain.Task;
import com.bnpparibas.risk.mrx.mqsim.producer.SpeTaskSubmitter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Trigger the priority test over HTTP:
 *
 *   GET /simulate?count=30
 *
 * Fires {@code count} tasks in parallel (one thread each, all released at once
 * for maximum contention), each with a deterministic priority 0..9. Then drains
 * the queue and compares, per task, the priority it was SENT with against the
 * JMS priority it was RECEIVED with. Returns a JSON pass/fail summary.
 */
@RestController
public class SimulatorController {

    private static final Logger LOG = LoggerFactory.getLogger(SimulatorController.class);

    private final SpeTaskSubmitter submitter;
    private final SpeTaskConsumer consumer;

    public SimulatorController(SpeTaskSubmitter submitter, SpeTaskConsumer consumer) {
        this.submitter = submitter;
        this.consumer = consumer;
    }

    @GetMapping("/simulate")
    public Map<String, Object> simulate(@RequestParam(defaultValue = "30") int count)
            throws InterruptedException {

        LOG.info("=== SIMULATE START count={} ===", count);

        ExecutorService pool = Executors.newFixedThreadPool(count);
        CountDownLatch ready = new CountDownLatch(count);
        CountDownLatch go = new CountDownLatch(1);
        CountDownLatch done = new CountDownLatch(count);
        AtomicInteger sendFailures = new AtomicInteger();

        for (int i = 0; i < count; i++) {
            final int priority = i % 10;                       // deterministic 0..9
            final String name = "TASK-" + i + "-p" + priority;
            pool.submit(() -> {
                ready.countDown();
                try {
                    go.await();                                // release all at once
                    Task task = new Task(UUID.randomUUID().toString(), name, priority);
                    submitter.sendMessage(task);
                } catch (Exception e) {
                    sendFailures.incrementAndGet();
                    LOG.error("send failed for {}: {}", name, e.getMessage(), e);
                } finally {
                    done.countDown();
                }
            });
        }

        ready.await();
        long start = System.nanoTime();
        go.countDown();
        boolean finished = done.await(30, TimeUnit.SECONDS);
        long sendMs = (System.nanoTime() - start) / 1_000_000L;
        pool.shutdown();

        // Drain and compare.
        List<SpeTaskConsumer.Result> results = consumer.drain(count);

        int matches = 0;
        int mismatches = 0;
        int[] histogram = new int[10];
        for (SpeTaskConsumer.Result r : results) {
            if (r.matches()) {
                matches++;
            } else {
                mismatches++;
            }
            int rp = r.getReceivedPriority();
            if (rp >= 0 && rp <= 9) {
                histogram[rp]++;
            }
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("requestedCount", count);
        result.put("sent", count - sendFailures.get());
        result.put("sendFailures", sendFailures.get());
        result.put("received", results.size());
        result.put("allSendsCompleted", finished);
        result.put("sendWallTimeMs", sendMs);
        result.put("priorityMatches", matches);
        result.put("priorityMismatches", mismatches);
        result.put("verdict",
                (mismatches == 0 && results.size() == count)
                        ? "PASS - every received priority equals the sent priority"
                        : "FAIL - priorities were lost or messages missing");

        Map<String, Integer> hist = new LinkedHashMap<>();
        for (int p = 0; p <= 9; p++) {
            hist.put("priority_" + p, histogram[p]);
        }
        result.put("receivedHistogram", hist);

        LOG.info("=== SIMULATE END verdict={} matches={} mismatches={} ===",
                result.get("verdict"), matches, mismatches);

        return result;
    }
}
