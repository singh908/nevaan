package com.bnpparibas.risk.mrx.mqsim.consumer;

import com.bnpparibas.risk.mrx.mqsim.domain.Task;
import com.bnpparibas.risk.mrx.mqsim.domain.TaskSerde;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import javax.jms.Destination;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.TextMessage;
import java.util.ArrayList;
import java.util.List;

/**
 * Drains the queue and, for each message, deserializes the Task and reads the
 * delivered JMS priority off the header (message.getJMSPriority()) — the same
 * call your IbmMQTaskListener.onMessage makes.
 *
 * Returns one Result per message capturing:
 *   - sentPriority      : task.getPriority() inside the payload (what the producer intended)
 *   - receivedPriority  : message.getJMSPriority() (what MQ actually delivered)
 * which is exactly the cross-check you do in prod logging.
 */
@Service
public class SpeTaskConsumer {

    private static final Logger LOG = LoggerFactory.getLogger(SpeTaskConsumer.class);

    /** Plain class (not a record) for Java 11 compatibility. */
    public static final class Result {
        private final String taskName;
        private final int sentPriority;
        private final int receivedPriority;

        public Result(String taskName, int sentPriority, int receivedPriority) {
            this.taskName = taskName;
            this.sentPriority = sentPriority;
            this.receivedPriority = receivedPriority;
        }

        public String getTaskName() {
            return taskName;
        }

        public int getSentPriority() {
            return sentPriority;
        }

        public int getReceivedPriority() {
            return receivedPriority;
        }

        public boolean matches() {
            return sentPriority == receivedPriority;
        }
    }

    private final JmsTemplate jmsTemplate;

    public SpeTaskConsumer(@Qualifier("consumerJmsTemplate") JmsTemplate jmsTemplate) {
        this.jmsTemplate = jmsTemplate;
    }

    /** Drain up to {@code expected} messages; stops on a 5s empty-queue timeout. */
    public List<Result> drain(int expected) {
        List<Result> results = new ArrayList<>(expected);

        jmsTemplate.execute(session -> {
            Destination dest = session.createQueue(jmsTemplate.getDefaultDestinationName());
            try (MessageConsumer consumer = session.createConsumer(dest)) {
                for (int i = 0; i < expected; i++) {
                    Message msg = consumer.receive(5000L);
                    if (msg == null) {
                        break; // queue drained
                    }
                    if (msg instanceof TextMessage) {
                        Task task = TaskSerde.fromJson(((TextMessage) msg).getText());
                        int received = msg.getJMSPriority();
                        Result r = new Result(task.getName(), task.getPriority(), received);
                        results.add(r);
                        LOG.info("RECEIVED task={} sentPriority={} receivedPriority={} {}",
                                task.getName(), task.getPriority(), received,
                                r.matches() ? "MATCH" : "*** MISMATCH ***");
                    }
                }
            }
            return null;
        }, true);

        return results;
    }
}
