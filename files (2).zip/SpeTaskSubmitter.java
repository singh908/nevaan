package com.bnpparibas.risk.mrx.mqsim.producer;

import com.bnpparibas.risk.mrx.mqsim.domain.Task;
import com.bnpparibas.risk.mrx.mqsim.domain.TaskSerde;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.MessageProducer;
import javax.jms.TextMessage;
import java.io.IOException;

/**
 * Faithful copy of your FIXED SpeMqTaskSubmitter:
 *  - serialize the Task with protostuff (throw on failure, don't ship empty)
 *  - send via the 4-arg producer.send so the per-message priority lands on MQ
 *  - priority is a LOCAL argument -> thread-safe under parallel callers
 *  - log AFTER the send so it reflects what actually went on the wire
 */
@Service
public class SpeTaskSubmitter {

    private static final Logger LOG = LoggerFactory.getLogger(SpeTaskSubmitter.class);
    private static final long NEVER_EXPIRE = 0L;

    private final JmsTemplate jmsTemplate;

    public SpeTaskSubmitter(@Qualifier("speJmsTemplate") JmsTemplate jmsTemplate) {
        this.jmsTemplate = jmsTemplate;
    }

    public void sendMessage(Task task) {
        jmsTemplate.execute(session -> {
            Destination dest = session.createQueue(jmsTemplate.getDefaultDestinationName());
            try (MessageProducer producer = session.createProducer(dest)) {

                String json;
                try {
                    json = TaskSerde.toJson(task);
                } catch (IOException e) {
                    LOG.error("Failed to serialize task {}: {}", task.getName(), e.getMessage(), e);
                    // Don't ship an empty/partial body to SPE — fail the send.
                    throw new java.io.UncheckedIOException(e);
                }

                TextMessage message = session.createTextMessage(json);
                producer.send(message,
                        DeliveryMode.PERSISTENT,
                        task.getPriority(),   // per-thread local — no shared state, no race
                        NEVER_EXPIRE);

                LOG.info("SENT     task={} priority={} dest={}",
                        task.getName(), task.getPriority(), dest);
            }
            return null;
        }, true);
    }
}
