package com.bnpparibas.risk.mrx.mqsim.config;

import com.ibm.mq.jms.MQConnectionFactory;
import com.ibm.msg.client.wmq.WMQConstants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.core.JmsTemplate;

import javax.jms.DeliveryMode;
import javax.jms.JMSException;

/**
 * Mirrors your TmSpringConfig:
 *   - MQConnectionFactory (CLIENT transport, reconnect options)
 *   - wrapped in CachingConnectionFactory so N parallel sends reuse a small
 *     pool of cached sessions instead of opening a connection per send
 *   - JmsTemplate with explicitQosEnabled(true) + PERSISTENT, default queue
 *
 * All connection settings come from application.properties so nothing is
 * hardcoded. Set them to your DEV queue manager before running.
 */
@Configuration
public class MqConfig {

    @Value("${mq.host}")
    private String host;

    @Value("${mq.port}")
    private int port;

    @Value("${mq.queueManager}")
    private String queueManager;

    @Value("${mq.channel}")
    private String channel;

    @Value("${mq.queue}")
    private String queueName;

    @Value("${mq.sessionCacheSize:30}")
    private int sessionCacheSize;

    /** Raw IBM MQ connection factory — same construction as TmSpringConfig. */
    @Bean
    public MQConnectionFactory mqConnectionFactory() throws JMSException {
        MQConnectionFactory factory = new MQConnectionFactory();
        factory.setHostName(host);
        factory.setPort(port);
        factory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
        factory.setQueueManager(queueManager);
        factory.setChannel(channel);
        factory.setClientReconnectOptions(WMQConstants.WMQ_CLIENT_RECONNECT);
        factory.setClientReconnectTimeout(10);
        // For a TLS channel, also set:
        //   factory.setSSLCipherSuite("...");
        //   factory.setSSLSocketFactory(yourSslSocketFactory);
        return factory;
    }

    /**
     * Cached/pooled factory. With 20-30 parallel senders this keeps the queue
     * manager seeing a handful of connections instead of one-per-send, and
     * eliminates a TLS handshake per message. Size the session cache to your
     * peak concurrency so threads don't block on a free session.
     */
    @Bean
    public CachingConnectionFactory cachingConnectionFactory(MQConnectionFactory mqConnectionFactory) {
        CachingConnectionFactory ccf = new CachingConnectionFactory(mqConnectionFactory);
        ccf.setSessionCacheSize(sessionCacheSize);
        ccf.setCacheProducers(true);
        ccf.setReconnectOnException(true);
        return ccf;
    }

    /**
     * The producer template. Exactly your prod config: explicit QoS on,
     * PERSISTENT delivery, a default queue. No setPriority() — priority is
     * supplied per-message by the 4-arg producer.send in the submitter.
     */
    @Bean(name = "speJmsTemplate")
    public JmsTemplate speJmsTemplate(CachingConnectionFactory cachingConnectionFactory) {
        JmsTemplate jmsTemplate = new JmsTemplate(cachingConnectionFactory);
        jmsTemplate.setExplicitQosEnabled(true);
        jmsTemplate.setDeliveryMode(DeliveryMode.PERSISTENT);
        jmsTemplate.setDefaultDestinationName(queueName);
        return jmsTemplate;
    }

    /**
     * Consumer template on the RAW factory (separate connection, like a real
     * separate consumer process). receiveTimeout lets the drain loop exit when
     * the queue is empty.
     */
    @Bean(name = "consumerJmsTemplate")
    public JmsTemplate consumerJmsTemplate(MQConnectionFactory mqConnectionFactory) {
        JmsTemplate jmsTemplate = new JmsTemplate(mqConnectionFactory);
        jmsTemplate.setDefaultDestinationName(queueName);
        jmsTemplate.setReceiveTimeout(5000L);
        return jmsTemplate;
    }
}
