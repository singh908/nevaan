# mq-priority-sim

Sends N tasks to a **real IBM MQ** queue in parallel and compares, per task,
the priority it was **sent** with against the priority it was **received** with
(`JMSPriority`). Proves the SPE priority fix end-to-end against an actual queue
manager.

Mirrors your production stack:

| Production                         | This app                                |
|------------------------------------|-----------------------------------------|
| `TmSpringConfig`                   | `MqConfig` (MQConnectionFactory + caching, explicitQos) |
| `SpeMqTaskSubmitter` (fixed)       | `SpeTaskSubmitter` (4-arg `producer.send`) |
| `IbmMQTaskListener.onMessage`      | `SpeTaskConsumer.drain` (reads `getJMSPriority()`) |
| `Task` + protostuff `JsonIOUtil`   | `Task` + `TaskSerde` (same JsonIOUtil)  |

Java 11, Spring Boot 2.7 (Spring 5, `javax.jms`).

## 1. Configure

Edit `src/main/resources/application.properties` with your DEV queue manager:

```
mq.host=...
mq.port=...
mq.queueManager=...
mq.channel=...
mq.queue=DEV.SPE.PROFILE
```

Match the IBM MQ client version in `pom.xml` (`com.ibm.mq.allclient`) and the
protostuff versions to whatever your real TMG/SPE project uses, to avoid wire/
classpath surprises.

If your channel is TLS, uncomment and set the SSL bits in `MqConfig.mqConnectionFactory()`.

## 2. Build & run

```bash
mvn spring-boot:run
```

## 3. Trigger

```bash
curl "http://localhost:8080/simulate?count=30"
```

`count` defaults to 30. Use 20-30 for a quick check.

## 4. Read the result

Console shows per-message `SENT ...` and `RECEIVED ... MATCH/MISMATCH` lines.
The HTTP response is a summary:

```json
{
  "requestedCount": 30,
  "sent": 30,
  "sendFailures": 0,
  "received": 30,
  "sendWallTimeMs": 318,
  "priorityMatches": 30,
  "priorityMismatches": 0,
  "verdict": "PASS - every received priority equals the sent priority",
  "receivedHistogram": { "priority_0": 3, "...": 0, "priority_9": 3 }
}
```

- **PASS + spread histogram** = the 4-arg `producer.send` is preserving priority
  under parallelism. That's the fix working.
- If you temporarily swap `SpeTaskSubmitter` to set priority via
  `message.setJMSPriority(...)` on the explicitQos template, you'll see
  everything collapse to `priority_4` and a **FAIL** — the original bug.

## Notes

- The queue should be `MSGDLVSQ(PRIORITY)` if you also want to observe
  priority *ordering*; for the send/receive priority *value* comparison this
  app does, the queue's delivery sequence doesn't matter.
- This drains the queue it sends to, so point `mq.queue` at a DEV/test queue,
  not a live one.
- 20-30 parallel sends is well within any sane channel limit. The
  `CachingConnectionFactory` keeps the QM seeing only a few connections.
