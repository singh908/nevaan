package com.bnpparibas.risk.mrx.mqsimulator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.MessageProducer;
import javax.jms.TextMessage;

/**
 * Sends a task to the queue using the 4-arg producer.send so the per-message
 * priority actually lands on the wire (the fix under test). Priority is passed
 * as a local argument, so this is thread-safe under parallel callers.
 */
@Service
public class MessageSender {

    private static final Logger LOG = LoggerFactory.getLogger(MessageSender.class);
    private static final long NEVER_EXPIRE = 0L;

    private final JmsTemplate jmsTemplate;

    public MessageSender(JmsTemplate jmsTemplate) {
        this.jmsTemplate = jmsTemplate;
    }

    public void sendMessage(String task, int priority) {
        jmsTemplate.execute(session -> {
            // NOTE: createQueue expects a PLAIN queue name (e.g. "DEV.SPE.PROFILE"),
            // not the "queue:///DEV.SPE.PROFILE" URI form. Make sure the template's
            // defaultDestinationName is set to a plain name in MqSimulatorConfig.
            Destination dest = session.createQueue(jmsTemplate.getDefaultDestinationName());
            try (MessageProducer producer = session.createProducer(dest)) {
                TextMessage message = session.createTextMessage(task);
                producer.send(message, DeliveryMode.PERSISTENT, priority, NEVER_EXPIRE);
                LOG.info("SENT     task={} priority={} dest={}",
                        task, priority, jmsTemplate.getDefaultDestinationName());
            }
            return null;
        }, true);
    }
}
