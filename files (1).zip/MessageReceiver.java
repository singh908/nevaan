package com.bnpparibas.risk.mrx.mqsimulator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import javax.jms.Destination;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.TextMessage;
import java.util.ArrayList;
import java.util.List;

/**
 * Drains the queue and reads the delivered JMS priority off each message
 * (message.getJMSPriority()) — the same call your real IbmMQTaskListener makes.
 * Returns one record per message so the controller can tally sent-vs-received.
 */
@Service
public class MessageReceiver {

    private static final Logger LOG = LoggerFactory.getLogger(MessageReceiver.class);

    public record Received(String task, int receivedPriority) {
    }

    private final JmsTemplate jmsTemplate;

    public MessageReceiver(JmsTemplate jmsTemplate) {
        this.jmsTemplate = jmsTemplate;
    }

    /** Drain up to {@code expected} messages; stops early on a 5s empty-queue timeout. */
    public List<Received> drain(int expected) {
        List<Received> out = new ArrayList<>(expected);

        jmsTemplate.execute(session -> {
            Destination dest = session.createQueue(jmsTemplate.getDefaultDestinationName());
            try (MessageConsumer consumer = session.createConsumer(dest)) {
                for (int i = 0; i < expected; i++) {
                    Message msg = consumer.receive(5000);
                    if (msg == null) {
                        break;
                    }
                    String body = (msg instanceof TextMessage tm) ? tm.getText() : "<non-text>";
                    int prio = msg.getJMSPriority();
                    out.add(new Received(body, prio));
                    LOG.info("RECEIVED task={} priority={}", body, prio);
                }
            }
            return null;
        }, true);

        return out;
    }
}
