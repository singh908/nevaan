package com.bnpparibas.risk.mrx.mqsimulator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Trigger the priority test over HTTP.
 *
 *   GET /simulate?count=100&threads=100
 *
 * Fires {@code count} tasks across {@code threads} parallel threads, each with a
 * priority 0..9, then drains the queue and compares the priority each task was
 * SENT with against the priority it was RECEIVED with (from JMSPriority).
 *
 * The sent priority is encoded into the task body ("name#prio") so the receiver
 * can verify the exact round-trip per message.
 */
@RestController
public class SimulatorController {

    private static final Logger LOG = LoggerFactory.getLogger(SimulatorController.class);

    private final MessageSender sender;
    private final MessageReceiver receiver;

    public SimulatorController(MessageSender sender, MessageReceiver receiver) {
        this.sender = sender;
        this.receiver = receiver;
    }

    @GetMapping("/simulate")
    public Map<String, Object> simulate(
            @RequestParam(defaultValue = "100") int count,
            @RequestParam(defaultValue = "100") int threads) throws InterruptedException {

        LOG.info("=== SIMULATE START count={} threads={} ===", count, threads);

        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch ready = new CountDownLatch(count);
        CountDownLatch go = new CountDownLatch(1);
        CountDownLatch done = new CountDownLatch(count);
        AtomicInteger sendFailures = new AtomicInteger();

        for (int i = 0; i < count; i++) {
            final int priority = i % 10;                          // deterministic 0..9
            final String task = "task-" + i + "#" + priority;     // encode sent priority in body
            pool.submit(() -> {
                ready.countDown();
                try {
                    go.await();                                  // release all at once = max contention
                    sender.sendMessage(task, priority);
                } catch (Exception e) {
                    sendFailures.incrementAndGet();
                    LOG.error("send failed for {}: {}", task, e.getMessage(), e);
                } finally {
                    done.countDown();
                }
            });
        }

        ready.await();
        long start = System.nanoTime();
        go.countDown();
        done.await(30, TimeUnit.SECONDS);
        long sendMs = (System.nanoTime() - start) / 1_000_000;
        pool.shutdown();

        // Drain and compare.
        List<MessageReceiver.Received> received = receiver.drain(count);

        int matches = 0, mismatches = 0;
        int[] histogram = new int[10];
        for (MessageReceiver.Received r : received) {
            int sent = parseSentPriority(r.task());
            if (sent == r.receivedPriority()) {
                matches++;
            } else {
                mismatches++;
                LOG.warn("MISMATCH task={} sent={} received={}", r.task(), sent, r.receivedPriority());
            }
            if (r.receivedPriority() >= 0 && r.receivedPriority() <= 9) {
                histogram[r.receivedPriority()]++;
            }
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("requestedCount", count);
        result.put("threads", threads);
        result.put("sent", count - sendFailures.get());
        result.put("sendFailures", sendFailures.get());
        result.put("received", received.size());
        result.put("sendWallTimeMs", sendMs);
        result.put("priorityMatches", matches);
        result.put("priorityMismatches", mismatches);
        result.put("verdict", mismatches == 0 && received.size() == count
                ? "PASS - every received priority equals the sent priority"
                : "FAIL - priorities were lost or messages missing");

        Map<String, Integer> hist = new LinkedHashMap<>();
        for (int p = 0; p <= 9; p++) {
            hist.put("priority_" + p, histogram[p]);
        }
        result.put("receivedHistogram", hist);

        LOG.info("=== SIMULATE END verdict={} matches={} mismatches={} ===",
                result.get("verdict"), matches, mismatches);

        return result;
    }

    /** Body is "task-N#prio"; extract the encoded sent priority. */
    private int parseSentPriority(String task) {
        int hash = task.lastIndexOf('#');
        if (hash < 0 || hash == task.length() - 1) {
            return -1;
        }
        try {
            return Integer.parseInt(task.substring(hash + 1));
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
