package com.bnpparibas.risk.mrx.mqsimulator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * App just boots and waits for HTTP. The simulation is triggered via
 * GET /simulate?count=100&threads=100 (see SimulatorController).
 *
 * Removed the old CommandLineRunner that auto-fired on startup, so the app
 * no longer sends on boot — you trigger it on demand instead.
 */
@SpringBootApplication
public class MqSimulatorApplication {

    public static void main(String[] args) {
        SpringApplication.run(MqSimulatorApplication.class, args);
    }
}
